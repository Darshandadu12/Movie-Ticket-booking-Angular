// seat-selection.component.ts
import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { SeatService } from '../seat.service';
import { Movie } from '../movie.model';
import { MovieService } from '../movie.service';

@Component({
  selector: 'app-seat-selection',
  templateUrl: './seat-selection.component.html',
  styleUrls: ['./seat-selection.component.css']
})
export class SeatSelectionComponent {
  availableSeats: boolean[][] = [];
  movies: Movie[] = [];
  selectedSeats: number[][] = [];
  totalTicketRate: number = 0;
  selectedMovie: Movie | undefined;
  selectedMovieTitle: string | null = null;
  unselectableSeats: { row: number; col: number }[] = [
    { row: 0, col: 0 },
    { row: 3, col: 4 },
    {row:9,col:19}
    // Add more seats as needed
  ];

  constructor(private seatService: SeatService, private router: Router,private movieService: MovieService) {
    this.availableSeats = this.seatService.getAvailableSeats();
    this.selectedMovie = this.seatService.getSelectedMovie(); // Get the selected movie from the service
    console.log('selectedMovie:', this.selectedMovie); // Add this line
  }

  isSeatAvailable(row: number, col: number): boolean {
    // Check if the seat is available (not booked)
    if (!this.availableSeats[row][col]) {
      return false;
    }

    // Check if the seat is in the unselectableSeats array
    for (const seat of this.unselectableSeats) {
      if (seat.row === row && seat.col === col) {
        return false;
      }
    }

    // If not in the unselectableSeats array, the seat is available and selectable
    return true;
  }


  
  isSelected(row: number, seat: number): boolean {
    return this.selectedSeats.some((selectedSeat) => selectedSeat[0] === row && selectedSeat[1] === seat);
  }
  isSeatUnselectable(row: number, col: number): boolean {
    // Check if the seat is in the unselectableSeats array
    return this.unselectableSeats.some((seat) => seat.row === row && seat.col === col);
  }

  toggleSeat(row: number, seat: number): void {
    if (this.isSeatAvailable(row, seat) && !this.isSeatUnselectable(row, seat)) {
      // Check if the seat is available and not unselectable
      if (this.isSelected(row, seat)) {
        this.deselectSeat(row, seat);
      } else {
        this.selectSeat(row, seat);
      }
    }
  }


  selectSeat(row: number, seat: number): void {
    if (this.seatService.isSeatAvailable(row, seat)) {
      this.selectedSeats.push([row, seat]);
    }
  }

  deselectSeat(row: number, seat: number): void {
    this.selectedSeats = this.selectedSeats.filter((selectedSeat) => !(selectedSeat[0] === row && selectedSeat[1] === seat));
  }

  calculateTotalTicketRate() {
    const seatPrice = 150;
    this.totalTicketRate = 0;
  
    // Calculate the total ticket rate based on selected seats
    this.totalTicketRate = this.selectedSeats.reduce((total, [row, seat]) => {
      return total + (this.isSeatAvailable(row, seat) ? seatPrice : 0);
    }, 0);
  }

  confirmSelection(): void {
    console.log('Selected Seats:', this.selectedSeats);
    // Navigate to the payment component
    this.router.navigate(['/payment']);
  }
  
}
