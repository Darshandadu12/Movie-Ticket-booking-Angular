// movie-list.component.ts
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router'; // Import Router
import { MovieService } from '../movie.service';
import { Movie } from '../movie.model';

@Component({
  selector: 'app-movie-list',
  templateUrl: './movie-list.component.html',
  styleUrls: ['./movie-list.component.css']
})
export class MovieListComponent implements OnInit {
  movies: Movie[] = [];
  city: string = '';
  theater: string = '';

  constructor(
    private route: ActivatedRoute,
    private router: Router, // Include Router in the constructor
    private movieService: MovieService
  ) { this.getMovies()}
getMovies(){this.movieService.getMovies().subscribe(movie=>{this.movies=movie})}
  ngOnInit(): void {
    this.route.queryParams.subscribe(params => {
      this.city = params['city'] || '';
      this.theater = params['theater'] || '';

      if (this.city && this.theater) {
        this.movieService.getMoviesByTheater(this.city, this.theater).subscribe(
          (movies) => {
            this.movies = movies;
          },
          (error) => {
            console.log('Error fetching movies:', error);
          }
        );
      }
    });
  }

  onMovieClick(movieId: number) {
    // Navigate to the movie details page using the movieId
    this.router.navigate(['/movie-details', movieId]);
  }
}
