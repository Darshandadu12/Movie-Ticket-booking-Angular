export class Theater {
  id: number;
  city: string;
  movie: string;
  name: string;
  address: string;

  constructor(id: number, city: string, movie: string, name: string, address: string) {
    this.id = id;
    this.city = city;
    this.movie = movie;
    this.name = name;
    this.address = address;
  }
}
