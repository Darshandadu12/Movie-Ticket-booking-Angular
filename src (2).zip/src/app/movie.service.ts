import { Injectable } from '@angular/core';
import { Movie } from './movie.model';
import { Theater } from './theater.model';
import { HttpClient } from '@angular/common/http';
import { map } from 'rxjs/operators';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class MovieService {
  private moviesUrl = 'http://localhost:3000/movies';

  private theaters: Theater[] = [
    new Theater(1, 'Bangalore', 'Looper', 'Theater A', 'Address 1'),
    new Theater(2, 'Bangalore', 'The Way Back', 'Theater A', 'Address 2'),
    new Theater(3, 'Bangalore', 'Avatar', 'Theater B', 'Address 3'),
    new Theater(4, 'Hyderabad', 'Acid Man', 'Theater C', 'Address 4'),
    new Theater(5, 'Hyderabad', 'Johnwick Chapter-IV', 'Theater A', 'Address 4'),
    new Theater(6, 'Hyderabad', 'The Little Mermaid', 'Theater A', 'Address 5'),
    new Theater(7, 'Hyderabad', 'The End of the Road Begins', 'Theater A', 'Address 6'),
    new Theater(8, 'Hyderabad', 'The Indiana Jones', 'Theater A', 'Address 7'),
    new Theater(9, 'Bangalore', 'The Last of Us', 'Theater A', 'Address 1'),
    new Theater(10, 'Bangalore', 'OppenHeimer', 'Theater A', 'Address 2'),
    new Theater(11, 'Bangalore', 'Scream', 'Theater B', 'Address 3'),
    new Theater(12, 'Bangalore', 'Insidious', 'Theater B', 'Address 3'),
    new Theater(13, 'Hyderabad', 'Aquaman', 'Theater C', 'Address 4'),
    new Theater(14, 'Hyderabad', 'The Witcher', 'Theater B', 'Address 5'),
    new Theater(15, 'Hyderabad', 'RenField', 'Theater B', 'Address 3'),
    new Theater(16, 'Hyderabad', 'The Covenant', 'Theater A', 'Address 2'),
    new Theater(17, 'Hyderabad', 'The Wrath of Becky', 'Theater D', 'Address 8'),
    // Add more theaters here
  ];

  constructor(private http: HttpClient) { }

  getMovies(): Observable<Movie[]> {
    return this.http.get<Movie[]>(this.moviesUrl);
  }

  getMoviesByCity(city: string): Observable<Movie[]> { // Corrected method name
    const url = `${this.moviesUrl}?city=${city}`;
    return this.http.get<Movie[]>(url); // Corrected return type
  }
  getMovieById(id: number): Observable<Movie | undefined> {
    const url = `${this.moviesUrl}/${id}`;
    return this.http.get<Movie>(url);
  }

  

  getMoviesByTheater(city: string, theater: string): Observable<Movie[]> {
    return this.getMovies().pipe(
      map(movies => movies.filter(movie => movie.city === city && movie.theater === theater))
    );
  }
}
