import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-success',
  templateUrl: './success.component.html',
  styleUrls: ['./success.component.css']
})
export class SuccessComponent implements OnInit {
  // You can define any additional properties or variables here, if needed

  constructor() {}

  ngOnInit(): void {
    // You can perform any additional logic here, if needed
  }
}
