import { Component } from '@angular/core';
@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent {
  featuredMovies = [
    {
      title: 'Looper',
      image: 'assets/looper.jpg',
      description: 'Face your past and fight your future',
      link: '/movies/movie1'
    },
    {
      title: 'The way back',
      image: 'assets/movie2.jpg',
      description: 'Embrage the tuff journey',
      link: '/movies/movie2'
    },
    {
      title: 'Avatar',
      image: 'assets/image3.jpg',
      description: 'We are just going to fight back',
      link: '/movies/movie3'
    },
    {
      title: 'Acid man',
      image: 'assets/movie4.jpg',
      description: 'The most ferocius man is here.',
      link: '/movies/movie4'
    },
    {
      title: 'Movie 5',
      image: 'assets/movie5.jpg',
      description: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit.',
      link: '/movies/movie5'
    },
    {
      title: 'Movie 6',
      image: 'assets/movie6.jpg',
      description: 'Praesent vitae metus vestibulum, vehicula dolor vel, finibus tellus.',
      link: '/movies/movie6'
    },
    {
      title: 'Movie 7',
      image: 'assets/movie7.jpg',
      description: 'Sed aliquet leo quis magna consectetur, nec consectetur velit lacinia.',
      link: '/movies/movie7'
    },
    {
      title: 'Movie 8',
      image: 'assets/movie8.jpg',
      description: 'Quisque eget erat eu ipsum posuere egestas ut nec velit.',
      link: '/movies/movie8'
    }

  ];

  popularEvents = [
    {
      title: 'Movie Screenings: New Releases',
      image: 'assets/movie-screenings.jpg',
      description: 'Experience the latest movie releases, blockbusters, and special screenings.',
      link: '/events/movie-screenings'
    },
    {
      title: 'Music Concerts: Rockin\' Beats',
      image: 'assets/music-concert.jpg',
      description: 'Enjoy live performances by popular artists and bands from various genres.',
      link: '/events/music-concerts'
    },
    {
      title: 'Stand-up Comedy Shows: Laugh Out Loud',
      image: 'assets/comedy-show.jpg',
      description: 'Get ready for an evening filled with laughter and hilarious stand-up acts.',
      link: '/events/comedy-shows'
    },
    {
      title: 'Theatrical Plays: Drama and Musicals',
      image: 'assets/theatrical-plays.jpg',
      description: 'Experience the magic of stage plays, dramas, and musicals by professional theater groups.',
      link: '/events/theatrical-plays'
    },
    {
      title: 'Sports Events: Cricket and Football',
      image: 'assets/sports-events.jpg',
      description: 'Cheer for your favorite teams in thrilling cricket and football matches.',
      link: '/events/sports-events'
    },
    {
      title: 'Workshops and Seminars: Skill Development',
      image: 'assets/workshops-seminars.jpg',
      description: 'Enhance your knowledge and skills with educational workshops and seminars.',
      link: '/events/workshops-seminars'
    },
    {
      title: 'Exhibitions and Fairs: Art and Culture',
      image: 'assets/exhibitions-fairs.jpg',
      description: 'Explore art exhibitions, trade fairs, and cultural events.',
      link: '/events/exhibitions-fairs'
    },
    {
      title: 'Live Performances: Music and Dance',
      image: 'assets/live-performances.jpg',
      description: 'Be captivated by live shows of dancers, singers, and other performers.',
      link: '/events/live-performances'
    },
    {
      title: 'Food Festivals: Tasty Treats',
      image: 'assets/food-festivals.jpg',
      description: 'Savor a variety of delicious cuisines at food tasting events and culinary festivals.',
      link: '/events/food-festivals'
    },
    {
      title: 'Fashion Shows: Runway Glamour',
      image: 'assets/fashion-shows.jpg',
      description: 'Witness the latest trends and style at glamorous runway fashion shows.',
      link: '/events/fashion-shows'
    }
  ];

  upcomingShows = [
    {
      title: 'Show 1',
      image: 'assets/show1.jpg',
      description: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit.',
      link: '/shows/show1'
    },
    {
      title: 'Show 2',
      image: 'assets/show2.jpg',
      description: 'Praesent vitae metus vestibulum, vehicula dolor vel, finibus tellus.',
      link: '/shows/show2'
    },
    {
      title: 'Show 3',
      image: 'assets/show3.jpg',
      description: 'Sed aliquet leo quis magna consectetur, nec consectetur velit lacinia.',
      link: '/shows/show3'
    },
    {
      title: 'Show 4',
      image: 'assets/show4.jpg',
      description: 'Quisque eget erat eu ipsum posuere egestas ut nec velit.',
      link: '/shows/show4'
    },
    {
      title: 'Show 5',
      image: 'assets/show5.jpg',
      description: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit.',
      link: '/shows/show5'
    },
    {
      title: 'Show 6',
      image: 'assets/show6.jpg',
      description: 'Praesent vitae metus vestibulum, vehicula dolor vel, finibus tellus.',
      link: '/shows/show6'
    },
    {
      title: 'Show 7',
      image: 'assets/show7.jpg',
      description: 'Sed aliquet leo quis magna consectetur, nec consectetur velit lacinia.',
      link: '/shows/show7'
    },
    {
      title: 'Show 8',
      image: 'assets/show8.jpg',
      description: 'Quisque eget erat eu ipsum posuere egestas ut nec velit.',
      link: '/shows/show8'
    }
  ];

  currentMovieIndex = 0;
  currentEventIndex = 0;
  currentShowIndex = 0;

  totalMovies = this.featuredMovies.length;
  totalEvents = this.popularEvents.length;
  totalShows = this.upcomingShows.length;

  scrollMovies(direction: number) {
    const moviesPerPage = 4;
    const totalMoviePages = Math.ceil(this.totalMovies / moviesPerPage);
  
    this.currentMovieIndex += direction * moviesPerPage;
  
    if (this.currentMovieIndex < 0) {
      this.currentMovieIndex = (totalMoviePages - 1) * moviesPerPage;
    } else if (this.currentMovieIndex >= this.totalMovies) {
      this.currentMovieIndex = 0;
    }
  }

  scrollEvents(direction: number) {
    const eventsPerPage = 4;
    const totalEventPages = Math.ceil(this.totalEvents / eventsPerPage);

    this.currentEventIndex += direction * eventsPerPage;

    if (this.currentEventIndex < 0) {
      this.currentEventIndex = (totalEventPages - 1) * eventsPerPage;
    } else if (this.currentEventIndex >= this.totalEvents) {
      this.currentEventIndex = 0;
    }
  }

  scrollShows(direction: number) {
    const showsPerPage = 4;
    const totalShowPages = Math.ceil(this.totalShows / showsPerPage);

    this.currentShowIndex += direction * showsPerPage;

    if (this.currentShowIndex < 0) {
      this.currentShowIndex = (totalShowPages - 1) * showsPerPage;
    } else if (this.currentShowIndex >= this.totalShows) {
      this.currentShowIndex = 0;
    }
  }
}
