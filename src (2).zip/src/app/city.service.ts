import { Injectable } from '@angular/core';
import { Observable, of, Subject } from 'rxjs';
import { Movie } from './movie.model';
import { MovieService } from './movie.service';
import { Theater } from './theater.model';

@Injectable({
  providedIn: 'root'
})
export class CityService {
  private cities: string[] = ['Cheepurupalli', 'Garividi', 'Vizianagaram', 'Vizag'];
  private selectedCitySubject = new Subject<string>();
  private selectedMovie: Movie | null = null; // New property to store the selected movie

  constructor(private movieService: MovieService) {}

  getCities(): Observable<string[]> {
    return of(this.cities);
  }

  setSelectedCity(city: string): void {
    this.selectedCitySubject.next(city);
  }

  getSelectedCity(): Observable<string> {
    return this.selectedCitySubject.asObservable();
  }

  // New method to store the selected movie
  setSelectedMovie(movie: Movie): void {
    this.selectedMovie = movie;
  }
  // New method to retrieve the selected movi
  getSelectedMovie(): Movie | null {
    return this.selectedMovie;
  }

  getMoviesByCity(city: string): Observable<Movie[]> { // Corrected method name
    return this.movieService.getMoviesByCity(city);
  }

  getTheatersForMovie(movieId: number): Observable<Theater[]> {
    // Implement the logic to fetch theaters for a particular movie here
    // For demo purposes, we'll return a mock data with some theaters
    const theaters: Theater[] = [
      new Theater(1, 'Cheepurupalli', 'Looper', 'Theater A', 'Address 1'),
      new Theater(2, 'Cheepurupalli', 'The Way Back', 'Theater A', 'Address 2'),
      new Theater(3, 'Cheepurupalli', 'Avatar', 'Theater B', 'Address 3'),
      // Add more theaters here as per your implementation
    ];

    return of(theaters);
  }
}
