import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { TheaterService } from '../theater.service';
import { Theater } from '../theater.model';

@Component({
  selector: 'app-theater-list',
  templateUrl: './theater-list.component.html',
  styleUrls: ['./theater-list.component.css']
})
export class TheaterListComponent implements OnInit {
  theaters: Theater[] = [];
  selectedCity: string = '';
  theatersForSelectedMovie: Theater[] = [];

  constructor(
    private theaterService: TheaterService,
    private route: ActivatedRoute,
    private router: Router
  ) {}

  ngOnInit() {
    this.route.paramMap.subscribe(params => {
      this.selectedCity = params.get('city')!;
      const movieId = +params.get('movieId')!; // Convert the movieId to a number using the '+' symbol
      this.fetchTheatersByCityAndMovie(this.selectedCity, movieId);
    });
  }

  fetchTheatersByCityAndMovie(city: string, movieId: number | null) {
    if (movieId !== null) {
      this.theaterService.getTheatersForMovie(movieId).subscribe(
        theatersData => {
          this.theatersForSelectedMovie = theatersData;
        },
        error => {
          console.log(error);
        }
      );
    }
  }
}
