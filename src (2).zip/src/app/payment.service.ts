import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { PaymentModel } from './payment-model.model';

@Injectable({
  providedIn: 'root'
})
export class PaymentService {
  private apiUrl = 'https://api.example.com/process-payment'; // Replace with your API URL

  constructor(private http: HttpClient) {}

  processPayment(payment: PaymentModel): Observable<any> {
    return this.http.post<any>(this.apiUrl, payment);
  }
}