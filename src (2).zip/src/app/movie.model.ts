// movie.model.ts
export interface Movie {
  id: number;
  title: string;
  description: string;
  releaseDate: string;
  duration: number;
  posterUrl: string;
  city: string;
  theater: string;
  trailerUrl: string;
  rating: number; // New property for the movie rating
}

export function calculateStarRating(rating: number): string {
  const roundedRating = Math.round(rating * 10) / 10;
  const starPercentage = (roundedRating / 10) * 100;
  return `${starPercentage}%`;
}
