import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from '../auth.service';

@Component({
  selector: 'app-cancellation',
  templateUrl: './cancellation.component.html',
  styleUrls: ['./cancellation.component.css']
})
export class CancellationComponent implements OnInit {
  cancellationForm: FormGroup;
  isSubmitted: boolean = false;
  registeredEmail: string = '';
  registeredPassword: string = '';

  constructor(
    private formBuilder: FormBuilder,
    private router: Router,
    private authService: AuthService
  ) {
    this.cancellationForm = this.formBuilder.group({
      email: ['', [Validators.required, Validators.email]],
      password: ['', Validators.required]
    });
  }

  ngOnInit() {
    this.registeredEmail = this.authService.getRegisteredEmail();
    this.registeredPassword = this.authService.getRegisteredPassword();
  }

  get formControls() {
    return this.cancellationForm.controls;
  }

  submitCancellationForm() {
    this.isSubmitted = true;

    if (this.cancellationForm.invalid) {
      return;
    }

    const email = this.cancellationForm.value.email;
    const password = this.cancellationForm.value.password;

    if (email === this.registeredEmail && password === this.registeredPassword) {
      console.log('Ticket Cancellation Form Submitted!');
      console.log('Form Values:', this.cancellationForm.value);
      this.cancellationForm.reset();
    } else {
      alert('Invalid email or password. Please provide the correct login credentials.');
      this.cancellationForm.get('password')?.reset(); // Reset the password field only
    }
  }

  navigateToLogin() {
    this.router.navigate(['/auth']);
  }
}
