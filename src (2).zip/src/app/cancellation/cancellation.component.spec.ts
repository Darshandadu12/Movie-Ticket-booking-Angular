import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ReactiveFormsModule } from '@angular/forms';
import { FormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';
import { CancellationComponent } from './cancellation.component';

describe('CancellationComponent', () => {
  let component: CancellationComponent;
  let fixture: ComponentFixture<CancellationComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [CancellationComponent],
      imports: [ReactiveFormsModule, FormsModule, BrowserModule]
    });
    fixture = TestBed.createComponent(CancellationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should invalidate form with empty email and password', () => {
    const form = component.cancellationForm;
    form.controls['email'].setValue(''); // Use bracket notation
    form.controls['password'].setValue(''); // Use bracket notation
    expect(form.invalid).toBe(true);
    expect(form.controls['email'].hasError('required')).toBeTruthy(); // Use hasError method
    expect(form.controls['password'].hasError('required')).toBeTruthy(); // Use hasError method
  });

  it('should invalidate form with invalid email format', () => {
    const form = component.cancellationForm;
    form.controls['email'].setValue('invalid_email'); // Use bracket notation
    form.controls['password'].setValue('validPassword'); // Use bracket notation
    expect(form.invalid).toBe(true);
    expect(form.controls['email'].hasError('email')).toBeTruthy(); // Use hasError method
  });

  it('should validate form with valid email and password', () => {
    const form = component.cancellationForm;
    form.controls['email'].setValue('valid_email@example.com'); // Use bracket notation
    form.controls['password'].setValue('validPassword'); // Use bracket notation
    expect(form.valid).toBe(true);
  });

  // ... Add more test cases for other validations as needed ...

});
