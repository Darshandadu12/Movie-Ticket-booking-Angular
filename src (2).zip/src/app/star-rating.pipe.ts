import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'starRating'
})
export class StarRatingPipe implements PipeTransform {
  transform(rating: number | undefined): string {
    if (typeof rating === 'number') {
      const fullStars = Math.floor(rating);
      const remainingStars = Math.round((rating - fullStars) * 10);
      const stars = '★'.repeat(fullStars) + (remainingStars > 0 ? '☆' : '');
      return `${rating}/10 (${stars})`;
    } else {
      return 'N/A';
    }
  }
}
