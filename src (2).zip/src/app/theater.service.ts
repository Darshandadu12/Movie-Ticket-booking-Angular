import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { Theater } from './theater.model';

@Injectable({
  providedIn: 'root'
})
export class TheaterService {
  private theaters: Theater[] = [
    new Theater(1, 'Cheepurupalli', 'Looper', 'Theater A', 'Address 1'),
    new Theater(2, 'Cheepurupalli', 'The Way Back', 'Theater A', 'Address 2'),
    new Theater(3, 'Garividi', 'Looper', 'Theater A', 'Address 3'),
    new Theater(4, 'Garividi', 'The Way Back', 'Theater A', 'Address 4'),
    new Theater(5, 'Garividi', 'Looper', 'Theater A', 'Address 5'),
    new Theater(6, 'Garividi', 'The Way Back', 'Theater A', 'Address 6'),
    // Add more theaters here
  ];

  constructor() { }

  getTheaters(): Observable<Theater[]> {
    return of(this.theaters);
  }

  getTheatersByCity(city: string): Observable<Theater[]> {
    // Replace the code here with your API call or backend logic to fetch theaters for the selected city
    // For demonstration purposes, I'm returning a mock data with theaters for the selected city
    if (city === 'Cheepurupalli') {
      return of([
        new Theater(1, 'Cheepurupalli', 'Looper', 'Theater A', 'Address 1'),
        new Theater(2, 'Cheepurupalli', 'The Way Back', 'Theater A', 'Address 2'),
        new Theater(3, 'Cheepurupalli', 'Avatar', 'Theater B', 'Address 3'),
        new Theater(9, 'Cheepurupalli', 'The Last of Us', 'Theater A', 'Address 1'),
        new Theater(10, 'Cheepurupalli', 'OppenHeimer', 'Theater A', 'Address 2'),
        new Theater(11, 'Cheepurupalli', 'Scream', 'Theater B', 'Address 3'),
        new Theater(12, 'Cheepurupalli', 'Insidious', 'Theater B', 'Address 3'),
      ]);
    } else if (city === 'Garividi') {
      return of([
        new Theater(4, 'Garividi', 'Acid Man', 'Theater C', 'Address 4'),
        new Theater(5, 'Garividi', 'Johnwick Chapter-IV', 'Theater A', 'Address 4'),
        new Theater(6, 'Garividi', 'The Little Mermaid', 'Theater A', 'Address 5'),
        new Theater(7, 'Garividi', 'The End of the Road Begins', 'Theater A', 'Address 6'),
        new Theater(8, 'Garividi', 'The Indiana Jones', 'Theater A', 'Address 7'),
        new Theater(13, 'Garividi', 'Aquaman', 'Theater C', 'Address 4'),
        new Theater(14, 'Garividi', 'The Witcher', 'Theater B', 'Address 5'),
        new Theater(15, 'Garividi', 'RenField', 'Theater B', 'Address 3'),
        new Theater(16, 'Garividi', 'The Covenant', 'Theater A', 'Address 2'),
      ]);
    } else {
      return of([]);
    }
  }
  
  getTheatersForMovie(movieId: number): Observable<Theater[]> {
    const selectedTheaters = this.theaters.filter(theater => parseInt(theater.movie) === movieId);
    return of(selectedTheaters);
  }
}
