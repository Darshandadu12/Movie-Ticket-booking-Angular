import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from '../auth.service';

@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent implements OnInit {
  registrationForm!: FormGroup;
  isSubmitted: boolean = false;

  constructor(
    private formBuilder: FormBuilder,
    private router: Router,
    public authService: AuthService
  ) {}
  ngOnInit() {
    this.registrationForm = this.formBuilder.group({
      username: ['', Validators.required],
      password: ['', [Validators.required, Validators.minLength(6)]],
      email: ['', [Validators.required, Validators.email]],
      address: ['', Validators.required],
      phone: ['', [Validators.required, Validators.pattern(/^\d{10}$/)]]
    });
  }
  get formControls() {
    return this.registrationForm.controls;
  }

  submitRegistrationForm() {
    this.isSubmitted = true;

    if (this.registrationForm.invalid) {
      return;
    }

    const email = this.registrationForm.value.email;
    const password = this.registrationForm.value.password;

    const isRegistered = this.authService.register(email, password);

    if (isRegistered) {
      alert('Registration successful!');
      console.log('Registration Form Submitted!');
      console.log('Form Values:', this.registrationForm.value);
    } else {
      alert('Failed to register. Please try again.');
    }

    this.registrationForm.reset();
  }

  navigateToLogin() {
    this.router.navigate(['/auth']);
  }
}
