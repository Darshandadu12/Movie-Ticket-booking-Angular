import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ReactiveFormsModule } from '@angular/forms';
import { FormsModule } from '@angular/forms';
import { AuthService } from '../auth.service';
import { BrowserModule } from '@angular/platform-browser';
import { RouterTestingModule } from '@angular/router/testing';

import { RegistrationComponent } from './registration.component';

describe('RegistrationComponent', () => {
  let component: RegistrationComponent;
  let fixture: ComponentFixture<RegistrationComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [RegistrationComponent],
      imports: [ReactiveFormsModule, RouterTestingModule, FormsModule, BrowserModule],
      providers: [AuthService]
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(RegistrationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should invalidate form with invalid email', () => {
    const form = component.registrationForm;
    form.controls['email'].setValue('invalid_email'); // Corrected access to 'email' control
    form.controls['password'].setValue('validPassword'); // Corrected access to 'password' control
    expect(form.valid).toBe(false);
  });

  it('should invalidate form with password less than 6 characters', () => {
    const form = component.registrationForm;
    form.controls['email'].setValue('valid_email@example.com');
    form.controls['password'].setValue('abc'); // Corrected access to 'password' control
    expect(form.valid).toBe(false);
  });

  it('should validate form with valid email and password', () => {
    const form = component.registrationForm;
    form.controls['email'].setValue('valid_email@example.com');
    form.controls['password'].setValue('validPassword');
    console.log('Form Value:', form.value);
    console.log('Email Control Validity:', form.controls['email'].valid);
    console.log('Password Control Validity:', form.controls['password'].valid);
    expect(form.controls['email'].valid).toBe(true);
    expect(form.controls['password'].valid).toBe(true);
  });
  
  

  // ... Add more test cases for other validations as needed ...

});
