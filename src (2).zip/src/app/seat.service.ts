import { Injectable } from '@angular/core';
import { Movie } from './movie.model';
@Injectable({
  providedIn: 'root'
})
export class SeatService {
  private rows = 10;
  private seatsPerRow = 20;
  private availableSeats: boolean[][] = [];
  private selectedMovie: Movie | undefined;

  constructor() {
    this.initAvailableSeats();
  }

  private initAvailableSeats(): void {
    this.availableSeats = Array(this.rows)
      .fill(false)
      .map(() => Array(this.seatsPerRow).fill(true));
  }

  getAvailableSeats(): boolean[][] {
    return this.availableSeats;
  }

  isSeatAvailable(row: number, seat: number): boolean {
    if (row >= 0 && row < this.rows && seat >= 0 && seat < this.seatsPerRow) {
      return this.availableSeats[row][seat];
    }
    return false;
  }
  setSelectedMovie(movie: Movie): void {
    this.selectedMovie = movie;
  }

  getSelectedMovie(): Movie | undefined {
    return this.selectedMovie;
  }
}