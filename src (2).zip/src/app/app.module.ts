import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { RouterModule, Routes } from '@angular/router';
import { ReactiveFormsModule } from '@angular/forms';
import { SeatService } from './seat.service';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { PaymentService } from './payment.service';
import { AuthService } from './auth.service';
import { CityService } from './city.service';
import { AppRoutingModule } from './app-routing.module';
import { MovieService } from './movie.service';
import { AppComponent } from './app.component';
import { TheaterService } from './theater.service';
import { AuthComponent } from './auth/auth.component';
import { RegistrationComponent } from './registration/registration.component';
import { RouterComponent } from './router/router.component';
import { MovieListComponent } from './movie-list/movie-list.component';
import { MovieDetailsComponent } from './movie-details/movie-details.component';
import { CityListComponent } from './city-list/city-list.component';
import { StarRatingPipe } from './star-rating.pipe';
import { TheaterListComponent } from './theater-list/theater-list.component';
import { SeatSelectionComponent } from './seat-selection/seat-selection.component';
import { PaymentComponent } from './payment/payment.component';
import { SuccessComponent } from './success/success.component';
import { HomeComponent } from './home/home.component';
import { CancellationComponent } from './cancellation/cancellation.component';
import { AdminComponent } from './admin/admin.component';

const routes: Routes = [
  { path: 'auth', component: AuthComponent },
  { path: 'home', component: HomeComponent },
  { path: 'registration', component: RegistrationComponent },
  { path: '', redirectTo: '/cities', pathMatch: 'full' },
  { path: 'cities', component: CityListComponent },
  { path: 'cities/:city/movies', component: MovieListComponent },
  { path: 'cities/:city/theaters/:movieId', component: TheaterListComponent },
  { path: 'seats/:theaterId', component: SeatSelectionComponent },
  { path: '', redirectTo: '/seat-selection', pathMatch: 'full' },
  { path: 'seat-selection', component: SeatSelectionComponent },
  { path: 'payment', component: PaymentComponent },
  { path: 'success', component: SuccessComponent },
  {path:'cancel',component:CancellationComponent},
  {path:'admin',component:AdminComponent}
];

@NgModule({
  declarations: [
    AppComponent,
    AuthComponent,
    RegistrationComponent,
    MovieListComponent,
    MovieDetailsComponent,
    RouterComponent,
    CityListComponent,
    TheaterListComponent,
    SeatSelectionComponent,
    PaymentComponent,
    SuccessComponent,
    HomeComponent,
    StarRatingPipe,
    CancellationComponent,
    AdminComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    RouterModule.forRoot(routes),
    ReactiveFormsModule,
    AppRoutingModule,
    HttpClientModule
  ],
  providers: [AuthService, MovieService, CityService, TheaterService, SeatService, PaymentService],
  bootstrap: [RouterComponent]
})
export class AppModule { }
