import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  private registeredEmail: string = '';
  private registeredPassword: string = '';

  constructor() {}

  setEmail(email: string) {
    this.registeredEmail = email;
  }

  setPassword(password: string) {
    this.registeredPassword = password;
  }

  authenticate(email: string, password: string): boolean {
    return email === this.registeredEmail && password === this.registeredPassword;
  }

  register(email: string, password: string): boolean {
    // Implement your logic to check if the user is already registered
    // and register the user if not already registered.
    // For the sake of example, let's assume the registration is successful.

    if (this.registeredEmail === '') {
      this.registeredEmail = email;
      this.registeredPassword = password;
      return true;
    } else {
      return false;
    }
  }

  getRegisteredEmail(): string {
    return this.registeredEmail;
  }

  getRegisteredPassword(): string {
    return this.registeredPassword;
  }
}
