import { Component } from '@angular/core';

@Component({
  selector: 'app-payment',
  templateUrl: './payment.component.html',
  styleUrls: ['./payment.component.css']
})
export class PaymentComponent {
  txtName: string = '';
  txtCardNumber: string = '';
  txtCVV: string = '';
  txtExpirationMonth: string = '';
  txtExpirationYear: string = '';
  txtUpiId: string = '';
  txtBankName: string = '';
  txtNetbankingPassword: string = '';

  paymentStatus: string = ''; // Add back the paymentStatus property
  isFormSubmitted: boolean = false;

  processPayment() {
    this.isFormSubmitted = true;
    if (this.isFormValid()) {
      this.paymentStatus = 'success';
      alert('Your booking is successful.');
    } else {
      this.paymentStatus = 'error';
      alert('Please fill in all required fields.');
    }
  }

  processUpiPayment() {
    this.isFormSubmitted = true;
    if (this.isUpiFormValid()) {
      this.paymentStatus = 'success';
      alert('Your booking is successful (UPI).');
    } else {
      this.paymentStatus = 'error';
      alert('Please fill in all required fields.');
    }
  }

  processNetbankingPayment() {
    this.isFormSubmitted = true;
    if (this.isNetbankingFormValid()) {
      this.paymentStatus = 'success';
      alert('Your booking is successful (Net Banking).');
    } else {
      this.paymentStatus = 'error';
      alert('Please fill in all required fields.');
    }
  }

  isFormValid(): boolean {
    const cleanedCardNumber = this.txtCardNumber.replace(/[\s-]/g, '');
    if (!/^[A-Z ]*$/.test(this.txtName)) {
      alert('Please enter name in capitals only.');
      return false;
    }
    if (!/^\d{16}$/.test(cleanedCardNumber)) {
      alert('Please enter a valid card number with 16 digits.');
      return false;
    }
    if (!/^\d{3}$/.test(this.txtCVV)) {
      alert('Please enter a valid 3-digit CVV.');
      return false;
    }
    if (!/^(0?[1-9]|1[0-2])$/.test(this.txtExpirationMonth)) {
      alert('Please enter an expiration month between 1 and 12.');
      return false;
    }
    if (!/^(202[3-9]|20[3-4]\d|2050)$/.test(this.txtExpirationYear)) {
      alert('Please enter a correct expiration year between 2023 and 2050.');
      return false;
    }
    return true;
  }
  

  isUpiFormValid(): boolean {
    if (!/.*@.*/.test(this.txtUpiId)) {
      alert('Please enter a correct UPI ID with the @ symbol.');
      return false;
    }
    return true;
  }

  isNetbankingFormValid(): boolean {
    if (!/^(?=.*[A-Z])(?=.*\d)(?=.*[@#$%^&!])[A-Za-z\d@#$%^&!]{8,}$/.test(this.txtNetbankingPassword)) {
      alert('Please enter a valid net banking password with at least one uppercase letter, one digit, and one special character.');
      return false;
    }
    return true;
  }
}
