export interface PaymentModel {
    firstName: string;
    lastName: string;
    email: string;
    phone: string;
    paymentMethod: string;
  }
  