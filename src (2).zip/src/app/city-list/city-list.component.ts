import { Component, OnInit } from '@angular/core';
import { CityService } from '../city.service';
import { Movie } from '../movie.model';
import { Theater } from '../theater.model';
import { SeatService } from '../seat.service';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-city-list',
  templateUrl: './city-list.component.html',
  styleUrls: ['./city-list.component.css']
})
export class CityListComponent implements OnInit {
  cities: string[] = [];
  movies$: Observable<Movie[]> | null = null;
  selectedCity: string = '';
  searchCity: string = '';
  theatersForSelectedMovie: Theater[] = [];
  selectedMovie: Movie | undefined;
  youtubeVideoId: string | null = null;

  constructor(
    private cityService: CityService,
    private seatService: SeatService
  ) {}

  ngOnInit(): void {
    this.getCities();
  }

  getYouTubeVideoIdFromUrl(url: string | undefined): string | null {
    if (!url) return null;

    const videoIdMatches = url.match(/(?:v=|\/embed\/|\/\d\/|\.be\/)([a-zA-Z0-9_-]{11})/);
    return videoIdMatches?.[1] || null;
  }

  getCities(): void {
    this.cityService.getCities().subscribe((citiesData: string[]) => {
      this.cities = citiesData;
    });
  }

  onSearch(): void {
    this.selectedCity = this.searchCity;
    this.movies$ = this.cityService.getMoviesByCity(this.selectedCity); // Use the 'movies$' observable
    this.theatersForSelectedMovie = []; // Clear theaters when a new city is searched
    this.selectedMovie = undefined; // Clear selected movie when a new city is searched
  }

  onMovieClick(movieId: number): void {
    if (this.movies$) {
      this.movies$.subscribe((movies: Movie[]) => {
        const movie = movies.find((movie) => movie.id === movieId);
        if (movie) {
          this.selectedMovie = movie;
          console.log('Selected Movie:', this.selectedMovie ? this.selectedMovie : 'Not selected');
          this.cityService.getTheatersForMovie(movieId).subscribe((theaters: Theater[]) => {
            this.theatersForSelectedMovie = theaters;

            // Update the selected movie in the service only if it is not undefined
            if (this.selectedMovie) {
              this.cityService.setSelectedMovie(this.selectedMovie);
            }
          });
        }
      });
    }
  }
  
  onBookTickets(theaterId: number) {
    // Set the selected movie in the seatService
    if (this.selectedMovie) {
      this.seatService.setSelectedMovie(this.selectedMovie);
    }

    // Navigate to the SeatListComponent and pass the theaterId as a parameter
    // Modify this route according to your routing configuration
    // e.g., this.router.navigate(['/cities', this.selectedCity, 'theaters', this.selectedMovie?.id, 'seats', theaterId]);
  }

  watchTrailer(trailerUrl: string): void {
    const trailerContainer = document.querySelector('.trailer-container');
    if (trailerContainer) {
      trailerContainer.innerHTML = ''; // Clear any existing content

      const videoId = this.getYouTubeVideoIdFromUrl(trailerUrl);
      if (videoId) {
        this.youtubeVideoId = videoId;
        // Create a YouTube iFrame and set its parameters
        const youtubeIframe = document.createElement('iframe');
        youtubeIframe.width = '560';
        youtubeIframe.height = '315';
        youtubeIframe.src = `https://www.youtube.com/embed/${videoId}`;
        youtubeIframe.frameBorder = '0';
        youtubeIframe.allowFullscreen = true;

        // Append the iFrame to the container
        trailerContainer.appendChild(youtubeIframe);
      }
    }
  }
}
