import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AuthService } from '../auth.service';

@Component({
  selector: 'app-auth',
  templateUrl: './auth.component.html',
  styleUrls: ['./auth.component.css']
})
export class AuthComponent {
  authForm: FormGroup;
  submitted: boolean = false;

  constructor(private formBuilder: FormBuilder, private authService: AuthService) {
    this.authForm = this.formBuilder.group({
      email: ['', [Validators.required, Validators.email]],
      password: ['', Validators.required]
    });
  }

  get formControls() {
    return this.authForm.controls;
  }

  onSubmit(): void {
    this.submitted = true;

    if (this.authForm.valid) {
      const { email, password } = this.authForm.value;
      const isAuthenticated = this.authService.authenticate(email, password);

      if (isAuthenticated) {
        alert('Login successful!');
      } else {
        alert('Invalid username or password.');
      }

      this.authForm.reset();
      this.submitted = false;
    } else {
      alert('Please enter valid email and password.');
    }
  }
}
