import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ReactiveFormsModule } from '@angular/forms';
import { FormsModule } from '@angular/forms';
import { AuthService } from '../auth.service';
import { BrowserModule } from '@angular/platform-browser';

import { AuthComponent } from './auth.component';

describe('AuthComponent', () => {
  let component: AuthComponent;
  let fixture: ComponentFixture<AuthComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [AuthComponent],
      imports: [ReactiveFormsModule, FormsModule, BrowserModule],
      providers: [AuthService]
    });
    fixture = TestBed.createComponent(AuthComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should set submitted to true when login is called', () => {
    component.login();
    expect(component.submitted).toBe(true);
  });

  it('should not call authService.authenticate when the form is invalid', () => {
    spyOn(component.authService, 'authenticate');
    component.login();
    expect(component.authService.authenticate).not.toHaveBeenCalled();
  });

  it('should call authService.authenticate when the form is valid', () => {
    component.authForm.get('email')?.setValue('test@example.com');
    component.authForm.get('password')?.setValue('password');
    spyOn(component['authService'], 'authenticate').and.returnValue(true);
    component.login();
    expect(component['authService'].authenticate).toHaveBeenCalledWith('test@example.com', 'password');
  }); 
});
